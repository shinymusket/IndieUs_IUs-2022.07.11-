function d_Value(target) {
	  // 선택한 option의 value 값
	  const driverValue = target.value;
	  console.log(target.value);
	  
		$.ajax({
			url : "/ius/bus/get_driver_tel",
			type : "POST",
			data : {
				staff_num : driverValue
			},
			success: function(data){
				console.log(data.staff_tel);
				$("#driver_tel").val(data.staff_tel);
			}
		})
};

