package com.indieus.ius.service;

import java.util.Map;

public interface AuthorityService {

	public Object getAuthorityInfo(Map<String, Object> map) throws Exception;

	public void setAuthorityInfo(Map<String, Object> map) throws Exception;
}
