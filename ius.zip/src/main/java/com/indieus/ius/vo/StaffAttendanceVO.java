package com.indieus.ius.vo;

public class StaffAttendanceVO {
	private String attend_code;
	private String staff_id;
	private String attend_date;
	private String attend_info;
	private String in_time;
	private String out_time;

	public String getAttend_code() {
		return attend_code;
	}
	public void setAttend_code(String attend_code) {
		this.attend_code = attend_code;
	}
	public String getStaff_id() {
		return staff_id;
	}
	public void setStaff_id(String staff_id) {
		this.staff_id = staff_id;
	}
	public String getAttend_date() {
		return attend_date;
	}
	public void setAttend_date(String attend_date) {
		this.attend_date = attend_date;
	}
	public String getAttend_info() {
		return attend_info;
	}
	public void setAttend_info(String attend_info) {
		this.attend_info = attend_info;
	}
	public String getIn_time() {
		return in_time;
	}
	public void setIn_time(String in_time) {
		this.in_time = in_time;
	}
	public String getOut_time() {
		return out_time;
	}
	public void setOut_time(String out_time) {
		this.out_time = out_time;
	}



}
