package com.indieus.ius.vo;

public class BudgetVO {
	private String budget_num;
	private String budget_year;
	private String budget_iE;
	private String budget_cls;
	private int budget_total;

	public String getBudget_num() {
		return budget_num;
	}
	public void setBudget_num(String budget_num) {
		this.budget_num = budget_num;
	}

	public String getBudget_year() {
		return budget_year;
	}
	public void setBudget_year(String budget_year) {
		this.budget_year = budget_year;
	}

	public String getBudget_iE() {
		return budget_iE;
	}
	public void setBudget_iE(String budget_iE) {
		this.budget_iE = budget_iE;
	}
	public String getBudget_cls() {
		return budget_cls;
	}
	public void setBudget_cls(String budget_cls) {
		this.budget_cls = budget_cls;
	}
	public int getBudget_total() {
		return budget_total;
	}
	public void setBudget_total(int budget_total) {
		this.budget_total = budget_total;
	}

}
