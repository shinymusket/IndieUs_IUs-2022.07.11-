package com.indieus.ius.vo;

public class ParentVO {
	private String parent_num;
	private String kinder_num;
	private String relation;
	private String parent_tel;
	private String parent_email;
	private String parent_sex;
	private String parent_birth;
	private String parent_name;

	public String getParent_num() {
		return parent_num;
	}
	public void setParent_num(String parent_num) {
		this.parent_num = parent_num;
	}
	public String getKinder_num() {
		return kinder_num;
	}
	public void setKinder_num(String kinder_num) {
		this.kinder_num = kinder_num;
	}
	public String getRelation() {
		return relation;
	}
	public void setRelation(String relation) {
		this.relation = relation;
	}
	public String getParent_tel() {
		return parent_tel;
	}
	public void setParent_tel(String parent_tel) {
		this.parent_tel = parent_tel;
	}
	public String getParent_email() {
		return parent_email;
	}
	public void setParent_email(String parent_email) {
		this.parent_email = parent_email;
	}
	public String getParent_sex() {
		return parent_sex;
	}
	public void setParent_sex(String parent_sex) {
		this.parent_sex = parent_sex;
	}
	public String getParent_birth() {
		return parent_birth;
	}
	public void setParent_birth(String parent_birth) {
		this.parent_birth = parent_birth;
	}
	public String getParent_name() {
		return parent_name;
	}
	public void setParent_name(String parent_name) {
		this.parent_name = parent_name;
	}



}
