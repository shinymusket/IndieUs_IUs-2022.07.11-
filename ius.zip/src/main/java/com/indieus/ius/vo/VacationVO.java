package com.indieus.ius.vo;

public class VacationVO {
	private int workNum;
	private String doc_Sub;
	private String vacation_reason;
	private String vacation_cat;
	private String vacation_period;
	private String staff_num;
	private String staff_name;
	private String workUpDate;
	private String status;
	private String workDownpdate;

	public String getWorkDownpdate() {
		return workDownpdate;
	}
	public void setWorkDownpdate(String workDownpdate) {
		this.workDownpdate = workDownpdate;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public int getWorkNum() {
		return workNum;
	}
	public void setWorkNum(int workNum) {
		this.workNum = workNum;
	}
	public String getDoc_Sub() {
		return doc_Sub;
	}
	public void setDoc_Sub(String doc_Sub) {
		this.doc_Sub = doc_Sub;
	}
	public String getVacation_reason() {
		return vacation_reason;
	}
	public void setVacation_reason(String vacation_reason) {
		this.vacation_reason = vacation_reason;
	}
	public String getVacation_cat() {
		return vacation_cat;
	}
	public void setVacation_cat(String vacation_cat) {
		this.vacation_cat = vacation_cat;
	}
	public String getVacation_period() {
		return vacation_period;
	}
	public void setVacation_period(String vacation_period) {
		this.vacation_period = vacation_period;
	}
	public String getStaff_num() {
		return staff_num;
	}
	public void setStaff_num(String staff_num) {
		this.staff_num = staff_num;
	}
	public String getStaff_name() {
		return staff_name;
	}
	public void setStaff_name(String staff_name) {
		this.staff_name = staff_name;
	}
	public String getWorkUpDate() {
		return workUpDate;
	}
	public void setWorkUpDate(String workUpDate) {
		this.workUpDate = workUpDate;
	}


}
