package com.indieus.ius.vo;

public class KinderVO {
	private String kinder_num;
	private String shuttle_num;
	private String staff_num;
	private String kinder_regYn;
	private String kinder_name;

	private String kinder_rrn1;
	private String kinder_rrn2;
	private String kinder_addr;
	private String kinder_zipcode;
	private String kinder_tel;
	private String kinder_regdate;
	private String kinder_retireDate;
	private String kinder_picture;

	private String class_name;
	private String father_name;
	private String mather_name;

	private String kinder_sex;
	private String kinder_birth;
	private String kinder_age;

	private String staff_name;
	private int allergy_code;

	private int allergy_check;

	public int getAllergy_check() {
		return allergy_check;
	}
	public void setAllergy_check(int allergy_check) {
		this.allergy_check = allergy_check;
	}
	public int getAllergy_code() {
		return allergy_code;
	}
	public void setAllergy_code(int allergy_code) {
		this.allergy_code = allergy_code;
	}

	public String getFather_name() {
		return father_name;
	}
	public void setFather_name(String father_name) {
		this.father_name = father_name;
	}
	public String getMather_name() {
		return mather_name;
	}
	public void setMather_name(String mather_name) {
		this.mather_name = mather_name;
	}
	public String getClass_name() {
		return class_name;
	}
	public void setClass_name(String class_name) {
		this.class_name = class_name;
	}
	public String getKinder_picture() {
		return kinder_picture;
	}
	public void setKinder_picture(String kinder_picture) {
		this.kinder_picture = kinder_picture;
	}
	public String getKinder_regdate() {
		return kinder_regdate;
	}
	public void setKinder_regdate(String kinder_regdate) {
		this.kinder_regdate = kinder_regdate;
	}
	public String getKinder_retireDate() {
		return kinder_retireDate;
	}
	public void setKinder_retireDate(String kinder_retireDate) {
		this.kinder_retireDate = kinder_retireDate;
	}


	public String getShuttle_num() {
		return shuttle_num;
	}
	public void setShuttle_num(String shuttle_num) {
		this.shuttle_num = shuttle_num;
	}

	public String getStaff_name() {
		return staff_name;
	}
	public void setStaff_name(String staff_name) {
		this.staff_name = staff_name;
	}
	public String getKinder_sex() {
		return kinder_sex;
	}
	public void setKinder_sex(String kinder_sex) {
		this.kinder_sex = kinder_sex;
	}
	public String getKinder_birth() {
		return kinder_birth;
	}
	public void setKinder_birth(String kinder_birth) {
		this.kinder_birth = kinder_birth;
	}
	public String getKinder_age() {
		return kinder_age;
	}
	public void setKinder_age(String kinder_age) {
		this.kinder_age = kinder_age;
	}
	public String getKinder_num() {
		return kinder_num;
	}
	public void setKinder_num(String kinder_num) {
		this.kinder_num = kinder_num;
	}
	public String getStaff_num() {
		return staff_num;
	}
	public void setStaff_num(String staff_num) {
		this.staff_num = staff_num;
	}
	public String getKinder_regYn() {
		return kinder_regYn;
	}
	public void setKinder_regYn(String kinder_regYn) {
		this.kinder_regYn = kinder_regYn;
	}
	public String getKinder_name() {
		return kinder_name;
	}
	public void setKinder_name(String kinder_name) {
		this.kinder_name = kinder_name;
	}

	public String getKinder_rrn1() {
		return kinder_rrn1;
	}
	public void setKinder_rrn1(String kinder_rrn1) {
		this.kinder_rrn1 = kinder_rrn1;
	}
	public String getKinder_rrn2() {
		return kinder_rrn2;
	}
	public void setKinder_rrn2(String kinder_rrn2) {
		this.kinder_rrn2 = kinder_rrn2;
	}
	public String getKinder_addr() {
		return kinder_addr;
	}
	public void setKinder_addr(String kinder_addr) {
		this.kinder_addr = kinder_addr;
	}
	public String getKinder_zipcode() {
		return kinder_zipcode;
	}
	public void setKinder_zipcode(String kinder_zipcode) {
		this.kinder_zipcode = kinder_zipcode;
	}
	public String getKinder_tel() {
		return kinder_tel;
	}
	public void setKinder_tel(String kinder_tel) {
		this.kinder_tel = kinder_tel;
	}


}
