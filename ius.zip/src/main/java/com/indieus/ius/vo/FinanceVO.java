package com.indieus.ius.vo;

public class FinanceVO {
	private String finance_num;
	private String budget_num;
	private String staff_num;
	private String finance_eYear;

	private String finance_eDate;
	private String finance_cls;
	private String finance_iE;
	private int finance_amount;

	private String budget_cls;
	private String staff_name;

	public String getBudget_cls() {
		return budget_cls;
	}
	public void setBudget_cls(String budget_cls) {
		this.budget_cls = budget_cls;
	}
	public String getStaff_name() {
		return staff_name;
	}
	public void setStaff_name(String staff_name) {
		this.staff_name = staff_name;
	}


	public String getFinance_eYear() {
		return finance_eYear;
	}
	public void setFinance_eYear(String finance_eYear) {
		this.finance_eYear = finance_eYear;
	}

	public String getFinance_num() {
		return finance_num;
	}
	public void setFinance_num(String finance_num) {
		this.finance_num = finance_num;
	}
	public String getBudget_num() {
		return budget_num;
	}
	public void setBudget_num(String budget_num) {
		this.budget_num = budget_num;
	}
	public String getStaff_num() {
		return staff_num;
	}
	public void setStaff_num(String staff_num) {
		this.staff_num = staff_num;
	}
	public String getFinance_eDate() {
		return finance_eDate;
	}
	public void setFinance_eDate(String finance_eDate) {
		this.finance_eDate = finance_eDate;
	}
	public String getFinance_cls() {
		return finance_cls;
	}
	public void setFinance_cls(String finance_cls) {
		this.finance_cls = finance_cls;
	}
	public String getFinance_iE() {
		return finance_iE;
	}
	public void setFinance_iE(String finance_iE) {
		this.finance_iE = finance_iE;
	}
	public int getFinance_amount() {
		return finance_amount;
	}
	public void setFinance_amount(int finance_amount) {
		this.finance_amount = finance_amount;
	}


}
