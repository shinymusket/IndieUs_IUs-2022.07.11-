package com.indieus.ius.vo;

public class ShuttleVO {

	String shuttle_num;
	String shuttle_name;
	String shuttle_carnum;
	String staff_num;
	String staff_name;
	String staff_tel;
	String route_id;
	String shuttle_hour;
	String shuttle_minute;
	String bus_stop;

	public String getShuttle_num() {
		return shuttle_num;
	}
	public void setShuttle_num(String shuttle_num) {
		this.shuttle_num = shuttle_num;
	}
	public String getShuttle_name() {
		return shuttle_name;
	}
	public void setShuttle_name(String shuttle_name) {
		this.shuttle_name = shuttle_name;
	}
	public String getShuttle_carnum() {
		return shuttle_carnum;
	}
	public void setShuttle_carnum(String shuttle_carnum) {
		this.shuttle_carnum = shuttle_carnum;
	}
	public String getStaff_num() {
		return staff_num;
	}
	public void setStaff_num(String staff_num) {
		this.staff_num = staff_num;
	}
	public String getStaff_name() {
		return staff_name;
	}
	public void setStaff_name(String staff_name) {
		this.staff_name = staff_name;
	}
	public String getStaff_tel() {
		return staff_tel;
	}
	public void setStaff_tel(String staff_tel) {
		this.staff_tel = staff_tel;
	}
	public String getShuttle_hour() {
		return shuttle_hour;
	}
	public void setShuttle_hour(String shuttle_hour) {
		this.shuttle_hour = shuttle_hour;
	}
	public String getShuttle_minute() {
		return shuttle_minute;
	}
	public void setShuttle_minute(String shuttle_minute) {
		this.shuttle_minute = shuttle_minute;
	}
	public String getBus_stop() {
		return bus_stop;
	}
	public void setBus_stop(String bus_stop) {
		this.bus_stop = bus_stop;
	}
	public String getRoute_id() {
		return route_id;
	}
	public void setRoute_id(String route_id) {
		this.route_id = route_id;
	}



}
