package com.indieus.ius.vo;

public class SpendVO {


	private int workNum;
	private String doc_Sub;
	private String spend_day;
	private String spend_cat;
	private String spend_list;
	private String spend_pay;
	private String staff_num;
	private String staff_name;
	private String workUpDate;
	private String workDowndate;

	public String getWorkDowndate() {
		return workDowndate;
	}
	public void setWorkDowndate(String workDowndate) {
		this.workDowndate = workDowndate;
	}
	private String etc;
	private String spend_reason;
	private String status;




	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public int getWorkNum() {
		return workNum;
	}
	public void setWorkNum(int workNum) {
		this.workNum = workNum;
	}
	public String getDoc_Sub() {
		return doc_Sub;
	}
	public void setDoc_Sub(String doc_Sub) {
		this.doc_Sub = doc_Sub;
	}
	public String getSpend_day() {
		return spend_day;
	}
	public void setSpend_day(String spend_day) {
		this.spend_day = spend_day;
	}
	public String getSpend_cat() {
		return spend_cat;
	}
	public void setSpend_cat(String spend_cat) {
		this.spend_cat = spend_cat;
	}
	public String getSpend_list() {
		return spend_list;
	}
	public void setSpend_list(String spend_list) {
		this.spend_list = spend_list;
	}
	public String getSpend_pay() {
		return spend_pay;
	}
	public void setSpend_pay(String spend_pay) {
		this.spend_pay = spend_pay;
	}
	public String getStaff_num() {
		return staff_num;
	}
	public void setStaff_num(String staff_num) {
		this.staff_num = staff_num;
	}
	public String getStaff_name() {
		return staff_name;
	}
	public void setStaff_name(String staff_name) {
		this.staff_name = staff_name;
	}
	public String getWorkUpDate() {
		return workUpDate;
	}
	public void setWorkUpDate(String workUpDate) {
		this.workUpDate = workUpDate;
	}
	public String getEtc() {
		return etc;
	}
	public void setEtc(String etc) {
		this.etc = etc;
	}
	public String getSpend_reason() {
		return spend_reason;
	}
	public void setSpend_reason(String spend_reason) {
		this.spend_reason = spend_reason;
	}


}
