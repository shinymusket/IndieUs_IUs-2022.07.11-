package com.indieus.ius.vo;

public class EquipClsVO {
	private String equip_cls_num;
	private int equip_num;
	private String equip_cls_name;

	public String getEquip_cls_num() {
		return equip_cls_num;
	}
	public void setEquip_cls_num(String equip_cls_num) {
		this.equip_cls_num = equip_cls_num;
	}
	public int getEquip_num() {
		return equip_num;
	}
	public void setEquip_num(int equip_num) {
		this.equip_num = equip_num;
	}
	public String getEquip_cls_name() {
		return equip_cls_name;
	}
	public void setEquip_cls_name(String equip_cls_name) {
		this.equip_cls_name = equip_cls_name;
	}


}
