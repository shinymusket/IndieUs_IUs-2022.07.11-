package com.indieus.ius.vo;

public class EworksBoardVO {

		private int workNum;
		private String workCategory;
		private String workUpDate;
		private String workDownDate;
		private int docNum;
		private String doc_Sub;
		private String status;


		public String getStatus() {
			return status;
		}
		public void setStatus(String status) {
			this.status = status;
		}
		public String getDoc_Sub() {
			return doc_Sub;
		}
		public void setDoc_Sub(String doc_Sub) {
			this.doc_Sub = doc_Sub;
		}
		private String staff_num;
		private int doc_cat_num;

		private String staff_name;


		public String getStaff_name() {
			return staff_name;
		}
		public void setStaff_name(String staff_name) {
			this.staff_name = staff_name;
		}
		public int getDocNum() {
			return docNum;
		}
		public void setDocNum(int docNum) {
			this.docNum = docNum;
		}
		public String getStaff_num() {
			return staff_num;
		}
		public void setStaff_num(String staff_num) {
			this.staff_num = staff_num;
		}
		public int getDoc_cat_num() {
			return doc_cat_num;
		}
		public void setDoc_cat_num(int doc_cat_num) {
			this.doc_cat_num = doc_cat_num;
		}
		public int getWorkNum() {
			return workNum;
		}
		public void setWorkNum(int workNum) {
			this.workNum = workNum;
		}
		public String getWorkCategory() {
			return workCategory;
		}
		public void setWorkCategory(String workCategory) {
			this.workCategory = workCategory;
		}
		public String getWorkUpDate() {
			return workUpDate;
		}
		public void setWorkUpDate(String workUpDate) {
			this.workUpDate = workUpDate;
		}
		public String getWorkDownDate() {
			return workDownDate;
		}
		public void setWorkDownDate(String workDownDate) {
			this.workDownDate = workDownDate;
		}


	}


