package com.indieus.ius.vo;

public class ShuttleVOP {
	private String shuttle_num;
	private String staff_num;
	private String shuttle_carNum;

	public String getShuttle_num() {
		return shuttle_num;
	}
	public void setShuttle_num(String shuttle_num) {
		this.shuttle_num = shuttle_num;
	}
	public String getStaff_num() {
		return staff_num;
	}
	public void setStaff_num(String staff_num) {
		this.staff_num = staff_num;
	}
	public String getShuttle_carNum() {
		return shuttle_carNum;
	}
	public void setShuttle_carNum(String shuttle_carNum) {
		this.shuttle_carNum = shuttle_carNum;
	}



}
