package com.indieus.ius.vo;

public class AllergyVO {

	private int allergy_Num;
	private String allergy_Name;


	public int getAllergy_Num() {
		return allergy_Num;
	}
	public void setAllergy_Num(int allergy_Num) {
		this.allergy_Num = allergy_Num;
	}
	public String getAllergy_Name() {
		return allergy_Name;
	}
	public void setAllergy_Name(String allergy_Name) {
		this.allergy_Name = allergy_Name;
	}


}
