package com.indieus.ius.vo;

public class BuyorderDocDraftVO {

	private int workNum;
	private String doc_Sub;
	private String product_name;
	private String product_amount;
	private String product_pay;
	private String product_money;
	private String staff_num;
	private String etc;
	private String staff_name;
	private String status;
	private String workUpdate;
	private String workDowndate;



	public String getWorkDowndate() {
		return workDowndate;
	}
	public void setWorkDowndate(String workDowndate) {
		this.workDowndate = workDowndate;
	}
	public String getWorkUpdate() {
		return workUpdate;
	}
	public void setWorkUpdate(String workUpdate) {
		this.workUpdate = workUpdate;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getStaff_num() {
		return staff_num;
	}
	public void setStaff_num(String staff_num) {
		this.staff_num = staff_num;
	}

	public String getEtc() {
		return etc;

	}

	public void setEtc(String etc) {
		this.etc = etc;

	}
	private String workUpDate;



	public int getWorkNum() {
		return workNum;
	}
	public void setWorkNum(int workNum) {
		this.workNum = workNum;
	}
	public String getDoc_Sub() {
		return doc_Sub;
	}
	public void setDoc_Sub(String doc_Sub) {
		this.doc_Sub = doc_Sub;
	}
	public String getProduct_name() {
		return product_name;
	}
	public void setProduct_name(String product_name) {
		this.product_name = product_name;
	}
	public String getProduct_amount() {
		return product_amount;
	}
	public void setProduct_amount(String product_amount) {
		this.product_amount = product_amount;
	}
	public String getProduct_pay() {
		return product_pay;
	}
	public void setProduct_pay(String product_pay) {
		this.product_pay = product_pay;
	}
	public String getProduct_money() {
		return product_money;
	}
	public void setProduct_money(String product_money) {
		this.product_money = product_money;
	}

	public String getStaff_name() {
		return staff_name;
	}
	public void setStaff_name(String staff_name) {
		this.staff_name = staff_name;
	}
	public String getWorkUpDate() {
		return workUpDate;
	}
	public void setWorkUpDate(String workUpDate) {
		this.workUpDate = workUpDate;
	}







}
