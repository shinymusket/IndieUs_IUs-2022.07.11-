package com.indieus.ius.vo;

public class ClassVO {

	private String class_num;
	private String staff_num;
	private String kinder_num;
	private String class_name;
	private String class_number;

	private String staff_name;
	private String kinder_name;
	private String staff_tel;



	public String getClass_number() {
		return class_number;
	}
	public void setClass_number(String class_number) {
		this.class_number = class_number;
	}
	public String getStaff_tel() {
		return staff_tel;
	}
	public void setStaff_tel(String staff_tel) {
		this.staff_tel = staff_tel;
	}
	public String getClass_num() {
		return class_num;
	}
	public void setClass_num(String class_num) {
		this.class_num = class_num;
	}
	public String getStaff_num() {
		return staff_num;
	}
	public void setStaff_num(String staff_num) {
		this.staff_num = staff_num;
	}
	public String getKinder_num() {
		return kinder_num;
	}
	public void setKinder_num(String kinder_num) {
		this.kinder_num = kinder_num;
	}
	public String getClass_name() {
		return class_name;
	}
	public void setClass_name(String class_name) {
		this.class_name = class_name;
	}
	public String getStaff_name() {
		return staff_name;
	}
	public void setStaff_name(String staff_name) {
		this.staff_name = staff_name;
	}
	public String getKinder_name() {
		return kinder_name;
	}
	public void setKinder_name(String kinder_name) {
		this.kinder_name = kinder_name;
	}


}
