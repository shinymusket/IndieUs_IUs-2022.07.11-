package com.indieus.ius.vo;

public class JobClassifiVO {

	private String staff_cls;
	private int job_number;
	private String job_Ename;
	private String job_Kname;

	public String getStaff_cls() {
		return staff_cls;
	}
	public void setStaff_cls(String staff_cls) {
		this.staff_cls = staff_cls;
	}

	public int getJob_number() {
		return job_number;
	}
	public void setJob_number(int job_number) {
		this.job_number = job_number;
	}
	public String getJob_Ename() {
		return job_Ename;
	}
	public void setJob_Ename(String job_Ename) {
		this.job_Ename = job_Ename;
	}
	public String getJob_Kname() {
		return job_Kname;
	}
	public void setJob_Kname(String job_Kname) {
		this.job_Kname = job_Kname;
	}


}
